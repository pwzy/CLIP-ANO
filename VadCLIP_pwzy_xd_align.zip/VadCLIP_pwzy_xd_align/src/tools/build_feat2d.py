import torch
from torch import nn
import torch.nn.functional as F

# 构建2d-TAN
# Ref: https://github.com/minghangz/TRM/blob/main/trm/modeling/trm/feat2d.py
class SparseMaxPool(nn.Module):
    def __init__(self, pooling_counts, N): # pooling_counts: [31] N: 32
        super(SparseMaxPool, self).__init__()
        mask2d = torch.zeros(N, N, dtype=torch.bool)  # 32*32 的Flase矩阵
        mask2d[range(N), range(N)] = 1 # 对角线元素变为True

        stride, offset = 1, 0
        maskij = []
        for c in pooling_counts:
            # fill all diagonal lines
            for _ in range(c):
                # fill a diagonal line
                offset += stride
                i, j = range(0, N - offset, stride), range(offset, N, stride)
                mask2d[i, j] = 1
                maskij.append((i, j))
            stride *= 2
        
        poolers = [nn.MaxPool1d(2, 1) for _ in range(pooling_counts[0])] # [MaxPool1d(), ..., MaxPool1d()] 共31个元素
        for c in pooling_counts[1:]:
            poolers.extend(
                [nn.MaxPool1d(3, 2)] + [nn.MaxPool1d(2, 1) for _ in range(c - 1)]
            )

        self.mask2d = mask2d.to("cuda")
        self.maskij = maskij # [(range(0, 31), range(1, 32)), (range(0, 30), range(2, 32)), ... (range(0, 1), range(31, 32))] 右上角索引
        self.poolers = poolers

    def forward(self, x):
        B, D, N = x.shape # [64, 512, 32]
        map2d = x.new_zeros(B, D, N, N) # map2d: 全零矩阵
        map2d[:, :, range(N), range(N)] = x  # fill a diagonal line
        for pooler, (i, j) in zip(self.poolers, self.maskij):
            x = pooler(x) # 第一次shape: [64, 512, 31] 第二次: [64, 512, 30]
            map2d[:, :, i, j] = x # 沿对角线往上填充
        return map2d


class SparseConv(nn.Module):
    def __init__(self, pooling_counts, N, hidden_size):
        super(SparseConv, self).__init__()
        mask2d = torch.zeros(N, N, dtype=torch.bool)
        mask2d[range(N), range(N)] = 1
        self.hidden_size = hidden_size
        stride, offset = 1, 0
        maskij = []
        for c in pooling_counts:
            # fill all diagonal lines
            for _ in range(c):
                # fill a diagonal line
                offset += stride
                i, j = range(0, N - offset, stride), range(offset, N, stride)
                mask2d[i, j] = 1
                maskij.append((i, j))
            stride *= 2

        self.convs = nn.ModuleList()
        self.convs.extend([nn.Conv1d(hidden_size, hidden_size, 2, 1) for _ in range(pooling_counts[0])])
        for c in pooling_counts[1:]:
            self.convs.extend(
                [nn.Conv1d(hidden_size, hidden_size, 3, 2)] + [nn.Conv1d(hidden_size, hidden_size, 2, 1) for _ in range(c - 1)]
            )

        self.mask2d = mask2d.to("cuda")
        self.maskij = maskij

    def forward(self, x):
        B, D, N = x.shape
        map2d = x.new_zeros(B, D, N, N)
        map2d[:, :, range(N), range(N)] = x  # fill a diagonal line
        for conv, (i, j) in zip(self.convs, self.maskij):
            x = conv(x)
            map2d[:, :, i, j] = x
        return map2d

def build_feat2d(feat2d_name = "pool"):
    pooling_counts = [31]
    num_clips = 32
    hidden_size = 512
    if feat2d_name == "pool":
        return SparseMaxPool(pooling_counts, num_clips)
    elif feat2d_name == "conv":
        return SparseConv(pooling_counts, num_clips, hidden_size)  
    else:
        raise NotImplementedError("No such feature 2d method as %s" % feat2d_name)

def build_feat2d_logits(feat2d_name = "pool"):
    pooling_counts = [31]
    num_clips = 32
    hidden_size = 1
    if feat2d_name == "pool":
        return SparseMaxPool(pooling_counts, num_clips)
    elif feat2d_name == "conv":
        return SparseConv(pooling_counts, num_clips, hidden_size)  
    else:
        raise NotImplementedError("No such feature 2d method as %s" % feat2d_name)

    

def mask2weight(mask2d, mask_kernel, padding=0):
    # from the feat2d.py,we can know the mask2d is 4-d: B, D, N, N
    weight = F.conv2d(mask2d[None, None, :, :].float(),
                          mask_kernel, padding=padding)[0, 0]
    weight[weight > 0] = 1 / weight[weight > 0]
    return weight

# Ref: https://github.com/minghangz/TRM/blob/main/trm/modeling/trm/proposal_conv.py
def get_padded_mask_and_weight(mask, conv):  # mask.shape: ([1, 1, 16, 16]) 上三角为True的bool矩阵  conv:各层的卷积
    masked_weight = torch.round(F.conv2d(mask.clone().float(), torch.ones(1, 1, *conv.kernel_size).cuda(), stride=conv.stride, padding=conv.padding, dilation=conv.dilation)) # 第一次： [1,1,44,44]
    masked_weight[masked_weight > 0] = 1 / masked_weight[masked_weight > 0]  #conv.kernel_size[0] * conv.kernel_size[1]
    padded_mask = masked_weight > 0
    return padded_mask, masked_weight

class ProposalConv(nn.Module):
    def __init__(self, input_size, hidden_size, k, num_stack_layers, output_size, mask2d):
        super(ProposalConv, self).__init__()
        self.num_stack_layers = num_stack_layers # 8
        self.mask2d = mask2d[None, None,:,:] #shape: ([1, 1, 32, 32]) 上三角为True的bool矩阵
        # Padding to ensure the dimension of the output map2d
        first_padding = (k - 1) * num_stack_layers // 2
        self.bn = nn.ModuleList([nn.BatchNorm2d(hidden_size)]) # hidden_size： 512
        self.convs = nn.ModuleList(
            [nn.Conv2d(input_size, hidden_size, k, padding=first_padding)]
        )
        for _ in range(num_stack_layers - 1):
            self.convs.append(nn.Conv2d(hidden_size, hidden_size, k)) #  ModuleList( (0): Conv2d(512, 512, kernel_size=(5, 5), stride=(1, 1), padding=(16, 16)) (1-7): 7 x Conv2d(512, 512, kernel_size=(5, 5), stride=(1, 1)))
            self.bn.append(nn.BatchNorm2d(hidden_size))
        # self.conv1x1_iou = nn.Conv2d(hidden_size, output_size, 1)
        self.conv1 = nn.Conv2d(hidden_size, output_size, 1)

    def forward(self, x): # x.shape: [64, 512, 32, 32]
        padded_mask = self.mask2d
        for i in range(self.num_stack_layers):
            x = self.bn[i](self.convs[i](x)).relu() # 第0次：[12, 512, 60, 60]
            padded_mask, masked_weight = get_padded_mask_and_weight(padded_mask, self.convs[i]) # 第0次： [1,1,60,60] masked_weight:[1,1,60,60] 第1次：[1, 1, 56, 56] 第7次：[1, 1, 32, 32]
            x = x * masked_weight
        out1 = self.conv1(x) # shape: [64, 512, 16, 16]  #名称仅供参考，，不代表真正作用
        # out2 = self.conv1x1_iou(x) # shape:[64, 512, 16, 16]
        return out1


def build_proposal_conv(mask2d):
    # input_size = cfg.MODEL.TRM.FEATPOOL.HIDDEN_SIZE # 512
    # hidden_size = cfg.MODEL.TRM.PREDICTOR.HIDDEN_SIZE # 512
    # kernel_size = cfg.MODEL.TRM.PREDICTOR.KERNEL_SIZE # 5
    # num_stack_layers = cfg.MODEL.TRM.PREDICTOR.NUM_STACK_LAYERS # 8
    # output_size = cfg.MODEL.TRM.JOINT_SPACE_SIZE # 512 
    # dataset_name = cfg.DATASETS.NAME # 'charades'
    input_size = 512
    hidden_size = 512
    kernel_size = 5
    num_stack_layers = 1
    output_size = 512 

    return ProposalConv(input_size, hidden_size, kernel_size, num_stack_layers, output_size, mask2d)

if __name__ == "__main__":

    # trans = Trans(embed_dim=512, depth=12, num_heads=4).cuda()
    # input = torch.randn(64, 32, 512).cuda()
    # output, _ = trans(input)
    # print(output.shape)

    # agg = Aggregate(len_feature=512).cuda()
    # input = torch.randn(64, 32, 512).cuda()
    # output = agg(input)
    # print(output.shape)

    # input = torch.randn(64, 512, 32).cuda() # [B, D, T]
    # feat2d = build_feat2d().cuda()
    # output = feat2d(input)
    # print(output.shape)
    # print(output)



    # from componets import build_feat2d
    feat2d = build_feat2d().cuda()
    feats_32 = torch.randn(64, 32, 512).cuda()
    map2d = feat2d(feats_32.permute(0, 2, 1)) 
    proposal_conv = build_proposal_conv(feat2d.mask2d).cuda()
    map2d_out = proposal_conv(map2d)
    # print(map2d_out.shape)
    # print(map2d_out[0,0])


    feat2d = build_feat2d_logits().cuda()
    feats_32 = torch.randn(64, 32, 1).cuda()
    map2d = feat2d(feats_32.permute(0, 2, 1)) 
    # proposal_conv = build_proposal_conv(feat2d.mask2d).cuda()
    # map2d_out = proposal_conv(map2d)
    print(map2d.shape)
    print(map2d[0,0])